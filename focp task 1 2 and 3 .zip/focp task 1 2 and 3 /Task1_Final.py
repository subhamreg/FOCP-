def get_user_input(prompt, valid_responses=None):
    while True:
        user_input = input(prompt).strip().upper()
        if valid_responses is not None and user_input not in valid_responses:
            print("Please answer '{}' or '{}'.".format(*valid_responses))
        else:
            return user_input

def calculate_total_price(num_pizzas, delivery_required, is_tuesday, used_app):
    pizza_price = 12
    delivery_cost = 2.5

    # Apply Tuesday discount
    if is_tuesday:
        pizza_price *= 0.5

    # Calculate total pizza cost
    total_pizza_cost = num_pizzas * pizza_price

    # Apply free delivery for five or more pizzas
    if num_pizzas >= 5 and delivery_required == 'Y':
        delivery_cost = 0

    # Calculate total cost including delivery
    total_cost = total_pizza_cost + delivery_cost

    # Apply app discount
    if used_app == 'Y':
        total_cost *= 0.75

    return round(total_cost, 2)

def main():
    print("BPP Pizza Price Calculator")
    print("==========================")

    num_pizzas = get_user_input("How many pizzas ordered? ")

    delivery_required = get_user_input("Is delivery required? (Y/N): ", valid_responses=['Y', 'N'])

    is_tuesday = get_user_input("Is it Tuesday? (Y/N): ", valid_responses=['Y', 'N'])

    used_app = get_user_input("Did the customer use the app? (Y/N): ", valid_responses=['Y', 'N'])

    total_price = calculate_total_price(int(num_pizzas), delivery_required, is_tuesday == 'Y', used_app == 'Y')

    print("\nTotal Price: £{:.2f}.".format(total_price))

if __name__ == "__main__":
    main()
