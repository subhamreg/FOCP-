import sys

def read_log_file(file_path):
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
        return lines
    except FileNotFoundError:
        print(f'Cannot open "{file_path}"!')
        sys.exit(1)

def analyze_log_file(lines):
    cat_visits = 0
    other_cats = 0
    total_time_in_house = 0
    visit_lengths = []

    for line in lines:
        if line.startswith("OURS"):
            cat_visits += 1
            entry_time = int(line.split(',')[1])
            exit_time = int(line.split(',')[2])
            visit_length = exit_time - entry_time
            total_time_in_house += visit_length
            visit_lengths.append(visit_length)
        elif line.startswith("THEIRS"):
            other_cats += 1

    return cat_visits, other_cats, total_time_in_house, visit_lengths

def format_time(minutes):
    hours, minutes = divmod(minutes, 60)
    return f'{hours} Hours, {minutes} Minutes'

def print_analysis(cat_visits, other_cats, total_time_in_house, visit_lengths):
    print("\nLog File Analysis")
    print("==================\n")
    print(f'Cat Visits: {cat_visits}')
    print(f'Other Cats: {other_cats}\n')
    print(f'Total Time in House: {format_time(total_time_in_house)}\n')

    if cat_visits > 0:
        average_duration = sum(visit_lengths) // cat_visits
        longest_duration = max(visit_lengths)
        shortest_duration = min(visit_lengths)

        print(f'Average Visit Length: {format_time(average_duration)}')
        print(f'Longest Visit:        {format_time(longest_duration)}')
        print(f'Shortest Visit:       {format_time(shortest_duration)}\n')

if __name__ == "__main__":
    # Check for command-line arguments
    if len(sys.argv) != 2:
        print("Missing command line argument!")
        sys.exit(1)

    file_path = sys.argv[1]
    log_lines = read_log_file(file_path)
    cat_visits, other_cats, total_time_in_house, visit_lengths = analyze_log_file(log_lines)
    print_analysis(cat_visits, other_cats, total_time_in_house, visit_lengths)
